# Add project specific ProGuard rules here.
# minifyEnabled is currently false, so this file is a placeholder for future use.
